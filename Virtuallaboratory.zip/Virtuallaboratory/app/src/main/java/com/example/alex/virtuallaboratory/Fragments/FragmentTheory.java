package com.example.alex.virtuallaboratory.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;

import com.example.alex.virtuallaboratory.R;

/**
 * Created by Alex on 30.10.2017.
 */

public class FragmentTheory extends android.support.v4.app.Fragment {

    public static FragmentTheory newInstance(String param) {
        FragmentTheory fragment = new FragmentTheory();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onResume(){
        super.onResume();
        getActivity().setTitle("Теория");
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_theory, container, false);

        WebView webView = (WebView)view.findViewById(R.id.web);
        webView.loadUrl("file:///android_asset/theory.html");
        return view;
    }
}
