package com.example.alex.virtuallaboratory.Fragments;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.example.alex.virtuallaboratory.R;

/**
 * Фрагмент для тестирования
 * TODO: Удалить этот фрагмент! Реализовать его функции в настройках!
 * */
public class FragmentConstSettings extends Fragment implements View.OnKeyListener{

    public static final String CONST ="CONST";
    public static final String RESTING_THRESHOLD = "RESTING_THRESHOLD";
    public static final String RESTING_MAX_THERESHOLD ="RESTING_MAX_THRESHOLD";
    public static final String ASCENDING_THRESHOLD ="ASCENDING_THRESHOLD";
    public static final String STATE_THRESHOLD ="STATE_THRESHOLD";
    public static final String COEFF_FILTRATION ="COEFF_FILTRATION";


    EditText et_resting, et_restingMax,et_ascending, et_state, et_coeff;
    SharedPreferences preferences;

    public FragmentConstSettings() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_const_settings, container, false);

        preferences =getActivity().getPreferences(Context.MODE_PRIVATE);

        et_resting = (EditText)view.findViewById(R.id.et_resting);
        et_restingMax = (EditText)view.findViewById(R.id.et_resting_max);
        et_ascending = (EditText)view.findViewById(R.id.et_ascending);
        et_state = (EditText)view.findViewById(R.id.et_state);
        et_coeff =(EditText)view.findViewById(R.id.et_coeff);

        et_resting.setOnKeyListener(this);
        et_restingMax.setOnKeyListener(this);
        et_ascending.setOnKeyListener(this);
        et_state.setOnKeyListener(this);
        et_coeff.setOnKeyListener(this);



        return view;
    }

    @Override
    public boolean onKey(View view, int i, KeyEvent keyEvent) {
        if(keyEvent.getAction() == keyEvent.ACTION_DOWN && (i == KeyEvent.KEYCODE_ENTER)){
            switch (view.getId()){
                case R.id.et_resting:{

                }
                case R.id.et_resting_max:{}
                case R.id.et_ascending:{}
                case R.id.et_state:{}
                case R.id.et_coeff:{}

            }
        }
        return false;
    }


}
