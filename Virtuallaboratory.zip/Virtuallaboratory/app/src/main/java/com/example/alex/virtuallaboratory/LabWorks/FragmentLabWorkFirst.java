package com.example.alex.virtuallaboratory.LabWorks;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.annotation.UiThread;
import android.support.design.widget.BaseTransientBottomBar;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.alex.virtuallaboratory.Analytics;
import com.example.alex.virtuallaboratory.R;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import static android.R.attr.parentActivityName;
import static android.R.attr.switchMinWidth;
import static android.R.attr.textColorHint;
import static android.R.attr.theme;


public class FragmentLabWorkFirst extends android.support.v4.app.Fragment implements SensorEventListener, View.OnClickListener
{

    Button btn_startMeasurement;
    TextView tv_accel, tv_cos ,tv_sin ,tv_angle ,tv_lastEx ;
            //tv_array;

    /**
     * View элементы для кастомного {@link Toast}
     * TODO: Создать класс объекты которого - проведенные измерения.
     */

    View toastView;
    Toast toast;
    TextView toastMessage;


    private SensorManager manager;
    boolean research= false;                                                                        // Флажок, началось ли исследование

    double alpha =0.85;                                                                             // Коэффициент для фильтра частот

    ArrayList<Double> arrayData=new ArrayList<>();                                                  // Массив с данными эксперимента

    private final double[] gravityComponents = new double[3];                                       // Компоненты ускорения свободного падения по осям
    private final double[] linAccelerationComponents = new double[3];                               // Компоненты линейного ускорения (вычисляем сами)
    private final double[] anglesGravity = new double[3];                                           // Угол наклона вычесленный через компоненты ускорения свободного падения
    private final double[] accelerometerComponentsFiltered = new double[3];                         // Компоненты ускорения по осям после фильтра
    private double acceleration=-1;


    private Timer timer;

    public FragmentLabWorkFirst() {
        // Required empty public constructor
    }

    /**===============================================================================================Android Lifecycle==**/
    @Override
    public void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView (LayoutInflater inflater, ViewGroup container,
                              Bundle savedInstanceState){

        /** Инициализация View элементов для фрагмента */
        View parent = inflater.inflate(R.layout.fragment_labwork_first, container, false);
        btn_startMeasurement =(Button)parent.findViewById(R.id.btn_start);

        tv_accel = (TextView)parent.findViewById(R.id.tv_accel);
        tv_angle = (TextView)parent.findViewById(R.id.tv_angle);
        tv_cos = (TextView)parent.findViewById(R.id.tv_cos);
        tv_sin = (TextView)parent.findViewById(R.id.tv_sin);
        tv_lastEx = (TextView)parent.findViewById(R.id.tv_last);
      //  tv_array = (TextView)parent.findViewById(R.id.tv_array);

        btn_startMeasurement.setOnClickListener(this);
        manager = (SensorManager)getActivity().getSystemService(Context.SENSOR_SERVICE);

        /**
         * Инициализация View элементов для кастромного {@link Toast}
         * Его создание и вывод на экран
         * */
        toastView = inflater.inflate(R.layout.toast_message, (ViewGroup)parent.findViewById(R.id.toast_layout));
        toastMessage = (TextView)toastView.findViewById(R.id.tv_toast);
        toastMessage.setText(getResources().getString(R.string.instruction1));
        toast = new Toast(getActivity().getApplicationContext());
        toast.setView(toastView);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.show();


        return parent;
    }

    @Override
    public void onPause() {
        super.onPause();

        /** Отключаем все дачтики*/
        manager.unregisterListener(this);

        timer.cancel();
    }

    @Override
    public void onResume() {
        super.onResume();

        /** Регистрируем дачтики*/
       //manager.registerListener(this, manager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION), SensorManager.SENSOR_DELAY_FASTEST);
        manager.registerListener(this, manager.getDefaultSensor(Sensor.TYPE_GRAVITY), SensorManager.SENSOR_DELAY_FASTEST);
        manager.registerListener(this, manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_FASTEST);

        timer=new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                         tv_angle.setText(format(anglesGravity[2]));
                         tv_accel.setText(format(acceleration));
                         tv_sin.setText(format(Math.sin(Math.toRadians(anglesGravity[2]))));
                         tv_cos.setText(format(Math.cos(Math.toRadians(anglesGravity[2]))));
                    }
                });
            }
        };
        timer.schedule(task,0,200);
    }

    /**===============================================================================================Sensor implements**/


    /**
     * Вызывается когда приходят новые данные датчиков
     * @param event - содержит тип датчика и массив с его данными
     *
     * Данные с акселерометра фильтруются фильтром низких частот
     * https://www.built.io/blog/applying-low-pass-filter-to-android-sensor-s-readings
     * Линейное ускорение вычисляется как разность данных акселерометра и компонент
     * ускорения свободного падения
     * */

    @Override
    public void onSensorChanged(SensorEvent event) {                                                // Вызывается при приеме новых данных датчиков

        if(event.sensor.getType() == Sensor.TYPE_GRAVITY){
            for(int i = 0; i < 3 ; i++){
                gravityComponents[i]=event.values[i];
            }
        }

        if(event.sensor.getType()==Sensor.TYPE_ACCELEROMETER){                                      // Если данные приходят с акселерометра

            for(int i = 0; i < 3; i++){
                accelerometerComponentsFiltered[i] =                                                // Фильтруем данные акселерометра
                        alpha*accelerometerComponentsFiltered[i]+ event.values[i]*(1-alpha);

                linAccelerationComponents[i] =                                                      // Вычисляем линейное ускорение
                        accelerometerComponentsFiltered[i]-gravityComponents[i];
            }
        }
        calculateOther();

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        //TODO: Найти применение функции реагирующей на измение погрешности датчиков
    }
    /**======================================================================================================================**/

    public void calculateOther() {
        /**Модуль ускорения свободного падения*/
        double gravity = Math.sqrt(

                gravityComponents[0]*gravityComponents[0]+
                        gravityComponents[1]*gravityComponents[1]+
                        gravityComponents[2]*gravityComponents[2]);

        /**Модуль ускорения падения*/
        acceleration = Math.sqrt(
                linAccelerationComponents[0]*linAccelerationComponents[0]+
                        linAccelerationComponents[1]*linAccelerationComponents[1]+
                        linAccelerationComponents[2]*linAccelerationComponents[2]);


        /**Вычисление угла к наклонной плоскости
         * TODO: Убрать первые два угла*/
        for(int i=0; i<3; i++){
            anglesGravity[i] = Math.toDegrees(Math.acos(gravityComponents[i]/gravity));
        }

        /**Текущий коэффициент трения*/
        Double currentFriction = Math.abs(Math.tan(Math.toRadians(anglesGravity[2]))-(acceleration-Analytics.zero)/(gravity*Math.cos(Math.toRadians(anglesGravity[2]))));

        if(research){

            if(arrayData==null){
                arrayData=new ArrayList<>();
            }

            if (Analytics.isEnded==false){
                if(Analytics.state==0 && Analytics.isChanged==false ){

                    Analytics.isChanged=true;
                    toastMessage.setText(getResources().getString(R.string.instruction2));
                    toast.show();
                    tv_accel.setTextColor(getResources().getColor(R.color.colorAccent));
                    btn_startMeasurement.setText(getResources().getString(R.string.cancelMeasurement));
                }

                if(Analytics.state==1 && Analytics.isChanged==false ){

                    Analytics.isChanged=true;
                    toastMessage.setText(getResources().getString(R.string.instruction3));
                    toast.show();
                    tv_accel.setTextColor(getResources().getColor(R.color.TextColor));
                }
                if(Analytics.flow(acceleration-Analytics.zero)){
                    arrayData.add(currentFriction);
                }
            }
            else{
                Analytics.isEnded=false;
                research = false;

                btn_startMeasurement.setText(getResources().getText(R.string.startMeasurement));

                for(int i = (arrayData.size()/9); i>0; i--){
                    arrayData.remove(arrayData.size()-1);
                    arrayData.remove(0);
                }
                StringBuilder builder = new StringBuilder()
                        .append(getResources().getString(R.string.friction))
                        .append(" "+ format(Analytics.getAverage(arrayData)))
                        .append("±"+format(Analytics.getAccuracy(arrayData)));
                tv_lastEx.setText(builder);


                Analytics.restartVariables();
/*
                String message="";
                for(int i=0;i<arrayData.size()-1;i++){
                    message+=arrayData.get(i)+"\n";
                }
                tv_array.setText(message);
  */
            }
        }
    }


    public void cancelMeasurement(){

        research=false;
        arrayData=null;
        Analytics.restartVariables();

        btn_startMeasurement.setText(getResources().getText(R.string.startMeasurement));
        tv_accel.setTextColor(ContextCompat.getColor(getContext(), R.color.TextColor));
    }


    String format(double value){
        return String.format(String.format("%(.3f",value));
    }

    @Override
    public void onClick(View v) {
    switch(v.getId()){
        case R.id.btn_start:{
            if(research){
                cancelMeasurement();
                toastMessage.setText("Измерение отменено");
                toast.show();
            }
            else {
                cancelMeasurement();
                research=true;
            }
        }

    }

    }
}

