package com.example.alex.virtuallaboratory;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Alex on 05.08.2017.
 * Обрабатывает данные во время эксперимента
 * Содержит статические методы для вычисления различных величин
 * С помощью фильтра исследует поведение данных
 */

public abstract class Analytics {

    /**
     * Этапы эксперимента
     * 1 - Resting ( Устройство покоится, ускорение стремится к 0)
     * 2 - Ascending (Устройство начинает скатываться, ускорение растет)
     * 3 - State (Устройство съежает, ускорение постоянно)
     * 4 - Hit (Момент удара устройства об горизонталюную поверхность, ускорение скачет)
     * * **/

    public static boolean isEnded = false;                                                          // Эксперимент закончен?
    public static int state = 0;                                                                    // Этап эксперимента
    public static boolean isChanged = false;                                                        // Изменился ли этап экспериента. Для графического интерфейса
    private static int index = 0;                                                                    // Индекс отвечающий за ложные условия этапа
    private static int secondIndex=0;

    private static int i=0;
    private static double filterAverage=0;
    private static double lastFilterAverage=0;
    private static double deltaFilter=-1;
    public static double zero=0;

    private static final int SIZE_FILTER = 9;                                                        // Размер фильтра
    private static final double RESTING_THRESHOLD = 0.14;                                            // Величина, ниже которой начинается состояние покоя
    private static final double RESTING_MAX_THRESHOLD = 0.5;                                         // Величина, выше которой начинается этап "съезжания" устройства
    private static final double ASCENDING_THRESHOLD = 0.1;                                           // Величина, ниже которой этап с постоянным ускорением. Разница между данными
    private static final double STATE_THRESHOLD = 1;                                                 // Разница между данными. Момент удара об поверхность
    private static final double MAX_DELTA=0.01;


    private static ArrayList<Double> filter;                                                          // Фильтр

    /** Анализирует данные и переключает последовательно этапы эксперимента
     *  @param value - текущее ускорение устройства
     *  @return - Принадлежит ли текущее ускорение этапу 3
     * */
    public static boolean flow(double value){

        if(filter==null){
            filter = new ArrayList<>();
        }

        checkSize();
        filter.add(value);

        switch (state){
            case 0:{

                i++;
                filterAverage+=value;                                                               //добавляем значение в контейнер
                if(i >= SIZE_FILTER){                                                                 //если в контейнере значений размерности фильтра
                    filterAverage/=SIZE_FILTER;                                                     // усредняем
                    deltaFilter=filterAverage-lastFilterAverage;                                    // Находим разницу между прошлым контейнером и новым
                    if(Math.abs(deltaFilter)<MAX_DELTA){                         // если разница меньше порога
                        secondIndex++;
                    }
                    else {
                        secondIndex--;
                    }
                    lastFilterAverage=filterAverage;                                                // новый контейнер загружаем в старый
                    filterAverage=0;                                                                // контейнер обнуляем
                    i=0;
                }

                if(Math.abs(value)< RESTING_THRESHOLD){                                             //условие с которого начинается "состояние покоя"
                    index++;                                                                        // запись количества выполненного условия
                }
                if(index==SIZE_FILTER){                                                             // если фильтр полностью в элементах для которых условние выполнилось
                    nextStage();                                                                        // Обнулить счетчик выполненных условий
                    isChanged = false;                                                              // Флажок для первого входа в сотояние обнулить
                }
                if(secondIndex==SIZE_FILTER*20){
                    isChanged= false;
                    zero=Math.abs(lastFilterAverage);
                }

                return false;                                                                       // значение не записывать в массив
            }
            case 1: {
                if(Math.abs(value)>RESTING_MAX_THRESHOLD){                                          //Условие с которого начинается соскальзывание
                    index++;                                                                        //запись количества выполненного условия
                }
                if(index==SIZE_FILTER){                                                             // если фильтр полностью в элементах для которых условние выполнилось
                    nextStage();                                                                    // Обнулить счетчик выполненных условий
                    isChanged = false;                                                              // Обнулить флажок для первого входа в состояние
                }
                return false;                                                                       // Значениене записывать
            }
            case 2:{
                if(Math.abs(value-filter.get(filter.size()-1)) < ASCENDING_THRESHOLD){              // Условие для состояния для равноускоренного движения
                    index++;
                }

                if(index==SIZE_FILTER/3){                                                           // если треть фильтра в элементах для которых условие выполнилось
                    nextStage();
                }
                return false;
            }
            case 3:{
                if(Math.abs(value-filter.get(filter.size()-1))<STATE_THRESHOLD){                    // Условие удара
                    index++;
                }
                if(index==SIZE_FILTER/4){                                                           // Если четверть фильтра в элементах для которых условие выолнилось
                    state=0;
                    index=0;
                    isEnded=true;                                                                   // Эксперимент окончен
                }
                return true;                                                                        // Записать в массив значений
            }
            default:{
                return false;
            }
        }
    }

    /**
     * Проверяет размер фильтра и укорачивает в случае превышения размера*/
    private static void checkSize(){
        if(filter.size() >= SIZE_FILTER){
            if(state==0){
                if(Math.abs(filter.get(0))< RESTING_THRESHOLD){
                    index--;
                }
                filter.remove(0);
            }
            if(state==1){
                if(Math.abs(filter.get(0)) > RESTING_MAX_THRESHOLD){
                    index--;
                }
                filter.remove(0);
            }
            if(state==2){
                if(Math.abs(filter.get(0)-filter.get(filter.size()-1))<ASCENDING_THRESHOLD){
                    index--;
                }
                filter.remove(0);
            }
            if(state==3){
                if(Math.abs(filter.get(0)-filter.get(filter.size()-1))<STATE_THRESHOLD){
                    index--;
                }
                filter.remove(0);
            }


        }
    }

    /**Вычисляет среднее арифметическое
     * @param array - массив данных
     * @return Среднее ариметическое данных массива
     * Возвращает -1 Если массив пуст*/
    public static double getAverage(ArrayList<Double> array){
        if(array.size()==0){
            return -1;
        }
        double sum =0;
        for(double val : array) sum+=val;
        return sum/array.size();
    }

   /**Вычисляет среднеквадратическую погрешность
    * @param array - массив данных
    * @return Среднеквадратическое отклонение
    * Возвращает -1 если массив пуст*/
    public static double getAccuracy(ArrayList<Double> array){
        if(array.size()==0){
            return -1;
        }

        double average =  getAverage(array);
        double sum =0;
        for (int i =0; i<array.size()-1;i++){
            sum +=((array.get(i)-average)*(array.get(i)-average));
        }
        sum = sum/(array.size()-1);
        return Math.sqrt(sum);
    }

    /**Обнуляет все перменные класса для повтороного исследования*/
    public static void restartVariables(){
        isEnded =false;
        isChanged =false;
        state = 0;
        index = 0;
        filter = null;

        secondIndex=0;
        i=0;
        filterAverage=0;
        lastFilterAverage=0;
        zero=0;
        deltaFilter=-1;
    }

    private static void nextStage(){
        state++;                                                                    // перейдти к следующему состоянию
        index=0;
        secondIndex=0;
    }
}
